package ac.grim.grimac.utils.enums;

public enum FluidTag {
    LAVA,
    WATER
}
